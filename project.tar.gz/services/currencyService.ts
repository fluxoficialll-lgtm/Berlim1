export { currencyService } from './real/currencyService';
export type { ConversionResult } from './real/currencyService';