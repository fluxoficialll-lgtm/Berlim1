
export { aiOrchestrator } from './core/AiOrchestrator';
export * from './types';
export * from './prompts/MarketingPrompts';

// Futuras exportações de prompts podem ser adicionadas aqui
// export * from './prompts/ModerationPrompts';
