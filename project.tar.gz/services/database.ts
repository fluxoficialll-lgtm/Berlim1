/**
 * Local Database Service Proxy
 * Points to the new modular database directory.
 */
export { db } from '../database/index';
