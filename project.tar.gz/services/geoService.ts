export { geoService } from './real/geoService';
export type { GeoData } from './real/geoService';