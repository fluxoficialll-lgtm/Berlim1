export { trackingService, generateTrackingLinkModel } from './real/trackingService';
export type { TrackingParams } from './real/trackingService';