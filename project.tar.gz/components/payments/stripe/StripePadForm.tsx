import React, { useState } from 'react';

interface StripePadFormProps {
    onBack: () => void;
    onSuccess: () => void;
}

export const StripePadForm: React.FC<StripePadFormProps> = ({ onBack, onSuccess }) => {
    const [loading, setLoading] = useState(false);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setTimeout(() => {
            setLoading(false);
            onSuccess();
        }, 2000);
    };

    return (
        <form onSubmit={handleSubmit} className="animate-fade-in text-left">
            <button type="button" onClick={onBack} className="text-gray-500 text-[10px] font-black uppercase mb-6 hover:text-white">
                <i className="fa-solid fa-arrow-left mr-2"></i> Canada Direct Debit (PAD)
            </button>

            <div className="space-y-5">
                <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-2xl mb-4">
                    <p className="text-[10px] text-red-400 font-bold leading-relaxed">
                        Pre-Authorized Debit (PAD) agreement. You agree to a one-time debit from your account.
                    </p>
                </div>

                <div className="input-group mb-0">
                    <label className="text-[9px] font-black text-gray-600 uppercase tracking-widest mb-1 block">Account Name</label>
                    <input className="input-field" placeholder="Full Name on Account" required />
                </div>

                <div className="grid grid-cols-3 gap-2">
                    <div className="input-group mb-0">
                        <label className="text-[8px] font-black text-gray-600 uppercase tracking-widest mb-1 block">Transit</label>
                        <input className="input-field" placeholder="5 digits" required maxLength={5} />
                    </div>
                    <div className="input-group mb-0">
                        <label className="text-[8px] font-black text-gray-600 uppercase tracking-widest mb-1 block">Inst.</label>
                        <input className="input-field" placeholder="3 digits" required maxLength={3} />
                    </div>
                    <div className="input-group mb-0 col-span-1">
                        <label className="text-[8px] font-black text-gray-600 uppercase tracking-widest mb-1 block">Account</label>
                        <input className="input-field" placeholder="No." required />
                    </div>
                </div>

                <button 
                    type="submit" 
                    disabled={loading}
                    className="w-full py-4 bg-[#00c2ff] text-black font-black rounded-xl shadow-lg mt-6 active:scale-95 transition-all"
                >
                    {loading ? <i className="fa-solid fa-circle-notch fa-spin"></i> : 'CONFIRM PAD DEBIT'}
                </button>
            </div>
        </form>
    );
};